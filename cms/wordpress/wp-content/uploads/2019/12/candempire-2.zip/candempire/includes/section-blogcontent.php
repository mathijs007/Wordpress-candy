<?php if(have_posts()): while(have_posts()): the_post();?>

   <p> <?php echo get_the_date('d/m/Y h:i:s');?></p>

    <?php the_content();?>

    <?php 
        //the_author();
        $fname = get_the_author_meta ('first_name');
        $lname = get_the_author_meta ('last_name');
        echo 'Posted by ' . $fname . ' ' . $lname;
    ?>


<?php endwhile; else: endif;?>